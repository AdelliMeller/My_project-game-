.. non-stop-the-game documentation master file, created by
   sphinx-quickstart on Sun Apr 21 15:12:29 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to non-stop-the-game's documentation!
=============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   code.rst
   code_user.rst




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
