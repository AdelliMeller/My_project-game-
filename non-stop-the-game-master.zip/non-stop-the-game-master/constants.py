"""
Константные значения для всей программы
"""


class Lines_speed:
    """
    Скорость линий
    """
    lines_speed = 5
    boost_speed = 91


width = 1280
height = 800
size = width, height
black = 0, 0, 0
white = 255, 255, 255
road_color = 216, 195, 165
boost_time = 44
shield_time = 100
x2_time = 100
cell_width = cell_height = 182
timer_value = 30
